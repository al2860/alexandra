package hintergrunddaten;

import java.io.IOException;


																						//Datenzugriffsobjekt
public class AutosDatenzugriffsobjekt extends Datenzugriffsobjekt {
	
	
	public AutosDatenzugriffsobjekt (String dateiName, boolean openForWrite) {

		super (dateiName, openForWrite);
	}
	

	public void write (Object obj) throws IOException { 								//Klasse um Autos zu speichern
		
		if (out != null) {
			
			Autos autoa = (Autos)obj;
			
			out.writeInt(autoa.size());
			
																						//Auto Objekt erzeugen und schreiben
			AutoDatenzugriffsobjekt AutoDZO = new AutoDatenzugriffsobjekt (null, out);
			
			for (Auto a: autoa) {
				
				AutoDZO.write(a);
			}
		}
	}
	
	public void read (Object obj) throws IOException {
		
		if (in != null) {
			
			Autos autosa = (Autos)obj;
			
														// Anzahl der Autos lesen:
			int nautos = in.readInt();
			
																								//Autos lesen
			AutoDatenzugriffsobjekt AutoDZO = new AutoDatenzugriffsobjekt (in, null);	
			for (int i=0; i<nautos; ++i) {
				Auto a = new Auto();
				AutoDZO.read(a);
				autosa.add(a);
			}
		}
	}
	
}




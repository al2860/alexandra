package hintergrunddaten;

import java.util.ArrayList;

																	//Erstellung einer Liste mit Autos

public class Autos extends ArrayList<Auto> {

		public void addAuto (Auto a) {
			
			super.add(a);
		}
		
		public int cabrio () {
			
			int ncabrio = 0;
			for (Auto a: this) {
				
				if (a.getcabrio()) 								//Ueberpruefen wie viele Cabrios im Fuhrpark sind
					ncabrio++;	  							
																//Hochzaehlen wie viele Autos Cabrio sind
			}
			return ncabrio;
		}

}

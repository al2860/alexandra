

package hintergrunddaten;

public class Auto {


	public String marke;			//Hinzufügen von Instanzvariablen 
	public String modell;
	public int leistung;
	public String farbe;
	private double kmstand;
	public int anzahltueren;
	
	private boolean cabrio;
	
	
	public Auto() {
	}
	
	public Auto (String marke, String modell, int leistung, String farbe, double kmstand, int anzahltueren, boolean cabrio) {
		
		this.marke = marke;
		this.modell = modell;
		this.leistung = leistung;
		this.farbe = farbe;				//Eingefügte Variablen, Attribute werden in das Auto übernommen 
		this.kmstand = kmstand;
		this.anzahltueren = anzahltueren;
		this.cabrio = cabrio;
		
	}
	public String getmarke() {
		return marke;
	}
	
	public void setmarke(String marke) {
		this.marke = marke;								
	}

	public String getmodell() {
		return modell;
	}															//Werte setzen

	public void setmodell(String modell) {
		this.modell = modell;
	}

	public int getleistung() {
		return leistung;
	}												//Werte setzen

	public void setleistung(int leistung) {
		this.leistung = leistung;
	}
																//Werte setzen
	
	public String getfarbe() {
		return farbe;
	}
	
	public void setfarbe(String farbe) {
		this.farbe = farbe;
	}

	public double kmstand () {
		return kmstand;
	}
	
	public void setkmstand (double kmstand) {
		this.kmstand = kmstand;
	}


	public int anzahltueren() {
		return anzahltueren;
	}
	
	public void setanzahltueren (int anzahltueren) {
		this.anzahltueren = anzahltueren;
	}



	public boolean getcabrio() {
		return cabrio;
	}

	public void setcabrio (boolean cabrio) {
		this.cabrio = cabrio;
	}
	
}

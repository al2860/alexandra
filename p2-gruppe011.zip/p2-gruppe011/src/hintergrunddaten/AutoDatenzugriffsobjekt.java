package hintergrunddaten;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import hintergrunddaten.Auto;



public class AutoDatenzugriffsobjekt extends Datenzugriffsobjekt {

	public AutoDatenzugriffsobjekt (String dateiName, boolean openForWrite) {			
		
		super (dateiName, openForWrite);											//Greift auf die Daten aus 
																					//Datenzugriffsobjekt zu 
	}
	
	public AutoDatenzugriffsobjekt (DataInputStream in, DataOutputStream out) {
		
		super (in, out);
	}
	
	public void write (Object obj) throws IOException {							//Klasse um ein Auto zu speichern 
		if (out != null) {
			
			Auto a = (Auto)obj;
			
			out.writeUTF	(a.getmarke());
			out.writeUTF	(a.getmodell());
			out.writeInt	(a.getleistung());
			out.writeUTF	(a.getfarbe());
			out.writeDouble	(a.kmstand());
			out.writeInt	(a.anzahltueren());
			out.writeBoolean(a.getcabrio());
		}
	}
	
	
	public void read (Object obj) throws IOException {
		
		if (in != null) {
			
			Auto a = (Auto)obj;											//Anzahl von Autos lesen 
			
			a.setmarke		(in.readUTF());
			a.setmodell			(in.readUTF());
			a.setleistung			(in.readInt());
			
			a.setfarbe				(in.readUTF());
			a.setkmstand		(in.readDouble());
			a.setanzahltueren		(in.readInt());
			
			
			a.setcabrio	(in.readBoolean());
			
		}
	}
}

 



package hintergrunddaten;

import java.io.DataInputStream;															//Die ganze Klasse Daten speichern, lesen 
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public abstract class Datenzugriffsobjekt {

	protected DataInputStream in;
	protected DataOutputStream out;
	
	
	public Datenzugriffsobjekt (String dateiName, boolean openForWrite) {

		try {
			if (openForWrite) {
			
				out =  new DataOutputStream (new FileOutputStream(dateiName));
			}
			else {
				
				in = new DataInputStream (new FileInputStream(dateiName));
			}
		}
		catch (IOException e) {													//Falls ein Fehler auftritt kommt eine Meldung 
			System.out.println (e.getMessage());			
		}
	}
	
	public Datenzugriffsobjekt (DataInputStream in, DataOutputStream out) {			
		
		this.in = in;
		this.out = out;
	}
	
	public void close () {
		
		try {
			if (in != null) in.close();
			if (out != null) out.close();
		}
		catch (IOException e) {
		}
	}
	
	public abstract void write (Object obj) throws IOException;
	public abstract void read (Object obj) throws IOException;

}

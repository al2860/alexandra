package oberflaeche;

import java.awt.BorderLayout;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

import oberflaeche.Liste;

import hintergrunddaten.AutosDatenzugriffsobjekt;
import hintergrunddaten.Auto;
import hintergrunddaten.Autos;


public class Frame extends JFrame implements ActionListener{
	
	private static Object auto;

	//Erstellen der Variablen
	
	Autos autoa = new Autos(); //ermoeglicht den Zugriff von GUIWohnungsliste
	
	private Liste guiListe = new Liste(this);
	
	//Erstellen der Instanzvariablen 
	
		private JLabel lblAnzahlAutos = new JLabel ("Alle Autos");
		private JTextField txtAnzahlAutos = new JTextField (10);
		
		private JLabel lblCabrio = new JLabel ("Cabrio ");
		private JTextField txtCabrio = new JTextField (10);
	
		
		private JButton btnNeuesAuto = new JButton ("Auto hinzufügen");
		private JButton btnEntfernen = new JButton ("Auto löschen");
	

	//Zuweisung der Elemente im Layout
		class NorthPanel extends Box {
		
			class Zeile extends JPanel {
				public Zeile() {
					setLayout (new FlowLayout(FlowLayout.CENTER));
					add (lblAnzahlAutos);
					add (txtAnzahlAutos);
					add (lblCabrio);
					add (txtCabrio);
			}
		}
			public NorthPanel () {
				
				super (BoxLayout.Y_AXIS);
				add (new Zeile());
			}
		}
		
		class SouthPanel extends JPanel {
			public SouthPanel() {
				setLayout (new FlowLayout(FlowLayout.CENTER));
				add (btnNeuesAuto);
				add(btnEntfernen);
			}
		}
		
		//Menuzeile wird erstellt und ihre Elemente werden hinzugef�gt.
		class MenueZeile extends JMenuBar {
			public MenueZeile () {
				add(new DateiZeile());

			}
				class DateiZeile extends JMenu {
					public DateiZeile() {
						super ("Datei");
						add(new NeuesFenster());
						add (new Oeffnen());
						add(new Speichernunter());
						addSeparator();
						add(new AllesBeenden());
					}
					
					class NeuesFenster extends JMenuItem implements ActionListener {
							 public NeuesFenster() {
								 super("Neues Fenster");
								 addActionListener(this);
							 }
							 public void actionPerformed(ActionEvent e) {
								 new Frame();
								 Frame.this.setSize(900, 600);
								 Frame.this.setVisible(true);
								 Frame.this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); //Damit nur ein Fenster anstatt alle schlie�t
								 Frame.this.setLocation(450, 250 ); //Versetztes �ffnen des Fensters
							}
					}
		
					class Oeffnen extends JMenuItem implements ActionListener {
			
						public Oeffnen () {
							super ("Oeffnen");
							addActionListener (this);
						}
						
					//Standardcode um Dateien zu Oeffnen
					
					public void actionPerformed(ActionEvent e) {
						
						JFileChooser fc = new JFileChooser();
						int returnValue = fc.showOpenDialog(Frame.this);
						if (returnValue == JFileChooser.APPROVE_OPTION) {
							File file = fc.getSelectedFile();
							String fileName = file.toString();
							AutosDatenzugriffsobjekt AutoDZO = new AutosDatenzugriffsobjekt (fileName, false);
							try {
								AutoDZO.read(autoa);
								AutoDZO.close();
							} 
							catch (IOException ex) {
							}
							updateGUI();
						}
					}
				}
					
					//Men�punkt f�r das Speichern.
					
				class Speichernunter extends JMenuItem implements ActionListener{
					
					public Speichernunter () {
						super ("Speichern unter");
						addActionListener (this);  
				
			}
				
					public void actionPerformed(ActionEvent arg0) {
						
						// Standardcode zum Speichern einer Datei
						
						JFileChooser fc = new JFileChooser();
						int returnValue = fc.showOpenDialog(Frame.this);
						if (returnValue == JFileChooser.APPROVE_OPTION) {
							File file = fc.getSelectedFile();
							String fileName = file.toString();
							AutosDatenzugriffsobjekt AutoDZO = new AutosDatenzugriffsobjekt (fileName, true);
							try {
								AutoDZO.write(autoa);
								AutoDZO.close();
							} 
							catch (IOException ex) {
							}
						}
					}
				
				}
			}
				
			//Button um Programm zu beenden
			
			class AllesBeenden extends JMenuItem implements ActionListener{
				
				public AllesBeenden() {
					super("Alles Beenden");
					addActionListener(this);
				}
			
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
					
				}
			}
		}
			
			
			
	public Frame () {
		
		setJMenuBar (new MenueZeile());
		
		
		
		setLayout (new BorderLayout());
		add (new NorthPanel(), BorderLayout.NORTH); //Panels der Startseite zuordnen
		add (new SouthPanel(), BorderLayout.SOUTH);
		add (guiListe        , BorderLayout.CENTER); //Liste der Startseite zuordnen
		
		
		setSize (700, 500);							//Groesse des Fensters	
		setTitle("Fuhrpark Verwaltung");			//Name des Fensters
		setVisible(true);							//Fenster sichtbar machen
		setDefaultCloseOperation(EXIT_ON_CLOSE);	//Fenster schliessbar machen	
								
		setResizable(false);						//Fenster feste Groesse zuordnen						
		setLocationRelativeTo(null);				//Fenster wird zentriert
		
		btnNeuesAuto.addActionListener(this);		//Button nach Klick Aktion ausfuehren lassen
		btnEntfernen.addActionListener(this);		//Button nach Klick Aktion ausfuehren lassen

	}
	
		public void actionPerformed (ActionEvent e) { //Aktion die nach Klick auf den Button ausgefuehrt wird
			if (e.getSource() == btnNeuesAuto) {
				
			// Neues Objekt wird erstellt, um mich Daten gefuellt zu werden
			Auto a = new Auto();
			// Bearbeitung des Objektes aufrufen
			DialogFrame dlg = new DialogFrame(this, a);
			
			if (dlg.closedOK) {
				autoa.addAuto (a);
				updateGUI();
				}
			}
				
			else if (e.getSource() == this.btnEntfernen){ //Aktion die nach Klick auf den Button ausgefuehrt wird
			
						int idx = guiListe.getSelectedIndex();
						if (-1 == idx) {							//Befehl um ausgewaehlte Spalte zu loeschen
							return; //wenn keine Zeile ausgewaehlt wurde
							
						}
						
						
						Object o = oberflaeche.Liste.myListModel.remove(idx);;
						guiListe.ensureIndexIsVisible(oberflaeche.Liste.myListModel.getSize());
					
				}
		}
				
				void updateGUI () {
					
					// Gesammelte Daten in GUIListe einfuegen
					guiListe.setAutos(autoa);
					// Vermietete Autos und Anzahl der Autos aktualisieren
					txtAnzahlAutos.setText(""+autoa.size());
					txtCabrio.setText(""+autoa.cabrio());		
				}
	
		public static void main (String[] args) {
		new Frame();
	}
			}
			
	
				




		

package oberflaeche;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import oberflaeche.Frame.NorthPanel;
import oberflaeche.Frame.SouthPanel;
import hintergrunddaten.Auto;

public class DialogFrame extends JDialog implements ActionListener{

	public boolean closedOK = false;	

	
	private Auto myauto;
	
	private JTextField 		marke = new JTextField(25);				//Eingabefelder erzeugen
	private JLabel			lblMarke   = new JLabel("Marke");		//Etikette fuer Eingabefelder erzeugen
		
	private JTextField 		modell    = new JTextField(3);				
	private JLabel			lblModell  = new JLabel("Modell");			
	
	private JTextField 		leistung    = new JTextField(3);
	private JLabel			lblLeistung  = new JLabel("Leistung");
	
	private JTextField 		farbe    = new JTextField(10);
	private JLabel			lblFarbe  = new JLabel("Farbe");
	
	private JTextField 		kmstand     = new JTextField(10);
	private JLabel			lblKmstand  = new JLabel("KM-Stand");
	
	private JTextField 		anzahltueren    = new JTextField(5);
	private JLabel			lblAnzahltueren  = new JLabel("Anzahlentueren");
	
	private JCheckBox		cabrio = new JCheckBox("Cabrio");		//Checkbox erzeugen
	
	private JButton			ok		  = new JButton("OK");				//Button erzeugen
	private JButton			abbrechen = new JButton("Abbrechen");

	public DialogFrame (Window parent, Auto a) {
		
		super (parent, "Daten bearbeiten", Dialog.ModalityType.APPLICATION_MODAL );
		myauto = a;
		
		
		marke.setText(a.getmarke());
		modell.setText(""+a.getmodell());
		farbe.setText(""+a.getfarbe());
		leistung.setText(""+a.getleistung());
		kmstand.setText(""+a.kmstand());
		anzahltueren.setText(""+a.anzahltueren());
		cabrio.setSelected(a.getcabrio());
		
		

		
		class NorthPanel extends Box {
			
			class FirstLine extends JPanel {
				public FirstLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));	
		add (lblMarke);		//Etiketten und Eingabefelder dem JPanel zuordnen
		add (marke);
		add (lblModell);		
		add (modell);
		add (lblFarbe);
		add (farbe);
		add (lblLeistung);
		add (leistung);
		add (lblKmstand);
		add (kmstand);
		add (lblAnzahltueren);
		add (anzahltueren);
		add (cabrio);
				}
			}
		public NorthPanel() {
			super(BoxLayout.X_AXIS);
			add (new FirstLine());
			}
		}
		class SouthPanel extends JPanel {
			public SouthPanel() {
				setLayout (new FlowLayout(FlowLayout.RIGHT));
		add (ok);												//Button dem JPanel zuordnen
		add (abbrechen);
				
			}
		}
		setLayout (new BorderLayout());
		add (new NorthPanel(), BorderLayout.NORTH);
		add (new SouthPanel(), BorderLayout.SOUTH);
		
		
		pack();
		
		ok.addActionListener (this);
		abbrechen.addActionListener (this);
		setResizable(false);
		setLocationRelativeTo(getParent());
		setVisible (true);
		
	}
		public void actionPerformed (ActionEvent e) { //Aktion die ausgef�hrt wird festlegen
				
			Object source = e.getSource();
			if (source == ok) {
				
				// Nach klick auf OK werden die eingegeben Daten in die Variablen �bergeben
			
				myauto.setmarke (marke.getText());
				myauto.setmodell(modell.getText());
				myauto.setfarbe(farbe.getText());
				myauto.setleistung(Integer.parseInt(leistung.getText()));
				myauto.setkmstand(Double.parseDouble(kmstand.getText()));
				myauto.setanzahltueren(Integer.parseInt(anzahltueren.getText()));
				

		myauto.setcabrio(cabrio.isSelected());
				
				closedOK = true; 
			}
			
			setVisible (false); //Fenster wird geschlossen, damit man wieder in das Hauptfenster kommt
}

}

package oberflaeche;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.JList;



import hintergrunddaten.Auto;
import hintergrunddaten.Autos;

public class Liste extends JList<String> {

	private Frame Frame;
	
	public static DefaultListModel<String> myListModel = new DefaultListModel<String> ();
	
	// Hier definieren wir einen Eventhandler, um auf Mausereignisse zu reagieren.
	 
	private class ListClickHandler extends MouseAdapter { //Aktion die nach Klick auf den Button ausgefuehrt wird
		
		public void mouseClicked(MouseEvent e) {
			
			// Listeneintrag doppelt klickbar machen
			if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) {
				// Aktion die nach Doppelklick ausgefuehrt wird
				int index = getSelectedIndex();
				if (index >= 0)	{
					
					Auto a = Frame.autoa.get(index);
					DialogFrame dlg = new DialogFrame (Frame, a);
					if (dlg.closedOK) {
						
						Frame.updateGUI(); //aktualisieren der Liste
					}
				}
			}
		}
	}
	
	public Liste (Frame frame) {
		
		this.Frame = frame; //Liste verbinden
		setModel (myListModel);
		addMouseListener (new ListClickHandler()); //klickbar machen
		
	}
	
	public void setAutos (Autos autoa) {
		
		// Zwischenzeitliches entfernen des Zwischenspeichers
		myListModel.removeAllElements();
		
		for (Auto a: autoa) {
			
			myListModel.addElement(a.getmarke());
		}
		
	}
}


 


